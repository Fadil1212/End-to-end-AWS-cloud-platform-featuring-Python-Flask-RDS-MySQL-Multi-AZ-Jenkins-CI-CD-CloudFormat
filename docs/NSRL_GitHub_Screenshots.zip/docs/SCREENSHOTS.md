# Project screenshots

Screenshots from the AWS Academy deployment and recovery validation, November 20–21, 2026. Cropped to remove browser and session headers.

### NSRL Cloud Query Application dashboard

![NSRL Cloud Query Application dashboard](screenshots/01-application-dashboard.png)

### MD5 hash search and result table

![MD5 hash search and result table](screenshots/02-hash-search.png)

### Filtered NSRL query example

![Filtered NSRL query example](screenshots/03-filtered-search.png)

### RDS Multi-AZ event and topology evidence

![RDS Multi-AZ event and topology evidence](screenshots/04-multi-az-evidence.png)

### Disaster recovery verification output

![Disaster recovery verification output](screenshots/05-dr-validation.png)

### Successful Jenkins pipeline completion

![Successful Jenkins pipeline completion](screenshots/06-jenkins-success.png)

