## Screenshots

[View application, query, failover, and CI/CD screenshots](docs/SCREENSHOTS.md)
